import { Component, Directive, ElementRef, HostBinding, HostListener, OnInit, Renderer2 } from '@angular/core';
@Directive({
  selector: '[something]'
})
export class changeTextDirective implements OnInit  {
    constructor( private el: ElementRef,private renderer:Renderer2) {
        console.log(el)
        // el.nativeElement.value
   //  el.nativeElement.innerHTML = '<b>Text is changed due to directive<b>'
    }
    ngOnInit(): void {
       
    }

    @HostBinding('attr.role') role = 'admin';

    @HostBinding('style.color') color = 'green';
    @HostBinding('class') classes = 'highlight highlight1';
   
   @HostListener('click',['$event']) onclick(event) {
     console.log(event)
     this.role = this.role === 'admin' ? 'guest': 'admin';
     if(this.role === 'admin') {
       this.role = 'guest'
     } else {
       this.role ='admin'
     }
   }

   @HostListener('mouseenter') onmouseenter() {
     this.color = 'pink'
   }
   @HostListener('mouseleave') onmouseleave() {
    this.color = 'blue'
  }

  @HostListener('keyup',['$event']) onkeydown(event) {
   // console.log(event)
    if(event.target.value === '34') {
      this.renderer.setAttribute(event.target,'role','jesus') // add
      this.renderer.addClass(event.target , 'sample')
    } else {
      this.renderer.removeClass(event.target , 'sample')
      this.renderer.removeAttribute(event.target,'role')
    }
    // if(event.key === '34') {}
  }

  @HostListener('keypress',['$event']) onkeypress(event) {
    console.log(event)
  }

  @HostListener('focus',['$event']) onfocus(event) {
    console.log(event)
  }
  @HostListener('blur',['$event']) onblur(event) {
    console.log(event)
  }
}