import { NgModule } from "@angular/core";
import {Routes,RouterModule} from '@angular/router';
import { Child1Component } from "./child1/child1.component";
import { Child2Component } from "./child2/child2.component";
import { RoutingComponent } from "./routing.component";

const routes: Routes = [
  
    {
        path: 'router',
        component: RoutingComponent, // this is the component with the <router-outlet> in the template
        children: [
          {
            path: 'child-a', // child route path
            component: Child1Component, // child route component that the router renders
          },
          {
            path: '', // child route path
            component: Child1Component, // child route component that the router renders
          },
          {
            path: 'child-b',
            component: Child2Component, // another child route component that the router renders
          },
          {
            path: '**',
            component: Child2Component, // another child route component that the router renders
          },
        ],
      },
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule],
})
export class routeRoutingModule{}