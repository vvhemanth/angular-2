import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Child1Component } from './child1/child1.component';
import { Child2Component } from './child2/child2.component';
import { RoutingComponent } from './routing.component';
import { RouterModule } from '@angular/router';
import { routeRoutingModule } from './route.router';

@NgModule({
  declarations: [
    Child1Component,
    Child2Component,
    RoutingComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    routeRoutingModule,
    RouterModule
  ],
  providers: []
})
export class routeModule { }
