import {
  Component, OnInit, AfterContentChecked, AfterContentInit, AfterViewChecked,
  AfterViewInit, DoCheck, OnChanges, OnDestroy, Input, SimpleChanges, ElementRef, ViewChild, ContentChild
} from '@angular/core';

@Component({
  selector: 'app-parent1',
  templateUrl: './parent1.component.html',
  styleUrls: ['./parent1.component.css']
})
export class Parent1Component implements OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked,
AfterViewInit, AfterViewChecked, OnDestroy {

displayChild: boolean = false;

constructor() {
  console.log("AppComponent:Constructor");
}

toggle() {
  this.displayChild = !this.displayChild;
}

@ViewChild('wrapper') wrapper:ElementRef;
@ContentChild('myContent') content:ElementRef;

ngOnChanges() {
  console.log("AppComponent:OnChanges");
}

ngOnInit() {
  console.log("AppComponent:OnInit");
}

ngDoCheck() {
  console.log("AppComponent:DoCheck");
}
ngAfterContentInit() {
  console.log("AppComponent:AfterContentInit");
  console.log('ngAfterContentInit - wrapper', this.wrapper);
  console.log('ngAfterContentInit - content', this.content);
  
}

ngAfterContentChecked() {
  console.log("AppComponent:AfterContentChecked");
}

ngAfterViewInit() {
  console.log("AppComponent:AfterViewInit");
  console.log('ngAfterViewInit - wrapper', this.wrapper);
  console.log('ngAfterViewInit - content', this.content);
}

ngAfterViewChecked() {
  console.log("AppComponent:AfterViewChecked");
}

ngOnDestroy() {
  console.log("AppComponent:OnDestroy");
}
}