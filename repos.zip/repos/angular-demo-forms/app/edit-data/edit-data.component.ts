import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserService } from '../services/user.service';
@Component({
  selector: 'app-edit-data',
  templateUrl: './edit-data.component.html',
  styleUrls: ['./edit-data.component.css']
})
export class EditDataComponent implements OnInit {
  userForm: boolean;
  constructor(private userService: UserService) { }
  editUserForm: boolean;
  editedUser: any = {};
  ngOnInit() {
    this.userService.userFormData.subscribe(data => {
      console.log(data)
      this.userForm = data;
    })

    this.userService.edituserFormData.subscribe(data =>{
      this.editUserForm = data;
    })

    this.userService.editedUser.subscribe(data =>{
      this.editedUser = data;
    })
   
  }
  


  cancelEdits() {
    this.editedUser = {};
    this.editUserForm = false;
  }

  updateUser() {
    this.userService.updateUser(this.editedUser);
    this.editUserForm = false;
    this.editedUser = {};
  }

}
