import { Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { User } from './models/user';
import { UserService } from './services/user.service';
import {EditDataComponent} from './edit-data/edit-data.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  users: User[];
  userForm: boolean;
  isNewUser: boolean;
  newUser: any = {};
  componetRef: any;
  editUserForm: boolean;
  editedUser: any = {};

  constructor(private userService: UserService,private resolver:ComponentFactoryResolver) { }


  @ViewChild('container',{read: ViewContainerRef}) container;
  ngOnInit() {
    this.users = this.getUsers(); //take data froms service
  }

  getUsers(): User[] {
    return this.userService.getUsersFromData();
  }



  showAddUserForm() {
    // resets form if edited user
    if (this.users.length) {
      this.newUser = {};
    }
    this.userForm = true;
    this.isNewUser = true;
    this.userService.userFormdata(this.userForm)
  }

  submiUser(user: User) {
    if (this.isNewUser) {
      // add a new user
      this.userService.addUser(user);
    }
    this.userForm = false;
    this.userService.userFormdata(this.userForm) // send data to service
  }



  removeUser(user: User) {
    this.userService.deleteUser(user);
  }



  cancelNewUser() {
    this.newUser = {};
    this.userForm = false;
    this.userService.userFormdata(this.userForm);
  }

  showEditUserForm(user: User) {
    if (!user) {
      this.userForm = false;
      return;
    }
    this.editUserForm = true;
    this.userService.edituserformData(this.editUserForm);
    this.editedUser = user;
    this.userService.editedData(user);// send data to service
    if(!this.componetRef) {
    const factory = this.resolver.resolveComponentFactory(EditDataComponent);
    this.componetRef = this.container.createComponent(factory);
    }
  }

 
}
