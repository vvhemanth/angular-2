import { NgModule } from "@angular/core";
import {Routes,RouterModule} from '@angular/router';
import { ArrayObjectComponent } from "./array-object/array-object.component";
import { DocumentComponent } from "./document/document.component";
import { ExternalJsonComponent } from "./external-json/external-json.component";
import { FunctionsComponent } from "./functions/functions.component";
import { JsonComponent } from "./json/json.component";
import { LocalStorageSessionStorageComponent } from "./local-storage-session-storage/local-storage-session-storage.component";
import { OtherThingsComponent } from "./other-things/other-things.component";
import { StringComponent } from "./string/string.component";
import { TableComponent } from "./table/table.component";


const routes: Routes = [
    {
        path:'document',
        component:DocumentComponent
    },
    {
        path:'array-object',
        component:ArrayObjectComponent
    },
    {
        path:'string',
        component:StringComponent
    },
    {
        path:'json',
        component:JsonComponent
    },
    {
        path:'functions',
        component:FunctionsComponent
    },
    {
        path:'external-json',
        component:ExternalJsonComponent
    },
    {
        path:'dynamic-data',
        component:JsonComponent
    },
    {
        path:'other-things',
        component:OtherThingsComponent
    },
    {
        path:'table',
        component:TableComponent
    },
    {
        path:'local-session',
        component:LocalStorageSessionStorageComponent
    },
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule],
})
export class AppRoutingModule{}