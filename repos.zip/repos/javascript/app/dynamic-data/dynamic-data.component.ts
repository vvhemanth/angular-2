import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamic-data',
  templateUrl: './dynamic-data.component.html',
  styleUrls: ['./dynamic-data.component.css']
})
export class DynamicDataComponent implements OnInit {
  constructor() { }

  ngOnInit() {
    let item = document.createElement('p')  // <p> </p>
    item.innerHTML = 'javascript7 works!';  // <p>javascript7 works!</p>
    document.getElementById('sample').appendChild(item) //<div id="sample"><p>javascript7 works!</p> </div>
  }

  onclick() {
    let ul = document.createElement('ul') //<ul></ul>
    ul.innerHTML = '<li>hemu</li>';
    document.getElementById('simple').appendChild(ul);


   // or
   //  let ul = document.createElement('ul');//<ul></ul>
     //<li></li>
   //  li.innerHTML or li.textContent
  // li.textContent = 'sai'// <li>sai</li>

let array = ['god','godess','devil',34,56]
 for(let i=0;i<3;i++) {
 
let li = document.createElement('li');

ul.appendChild(li) 
 }


   //<ul><li>sai</li></ul>

    document.getElementById('simple1').appendChild(ul);




  }


  onclick1() {

    let li = document.createElement('li') //<li></li>
    let text = document.createTextNode('water') //water
   li.appendChild(text) // <li>water</li>
    let ul = document.getElementById('menu');
    ul.insertBefore(li,ul.childNodes[2]);




    

  }


  onclick2() {
var textNode  = document.createTextNode('ice'); // ice

var item = document.getElementById('menu').childNodes[2];// second item <li>
item.replaceChild(textNode,item.childNodes[0])


  }

  onclick3() {
    let ul = document.getElementById('menu'); 
    // <ul> <li> water</li></ul>

    ul.removeChild(ul.childNodes[0])
  }
}
