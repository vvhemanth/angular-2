import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-functions',
  templateUrl: './functions.component.html',
  styleUrls: ['./functions.component.css']
})
export class FunctionsComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

  // functions will do repetitve tasks ,function will minimize the logic 
  submit() {
    let obj = {
      name:'hemanth',
      age:28,
      sample: function(a,b) {
        return a+","+ b
      }
    }

    // let item = obj.sample();
    // console.log(item)
    let item1 =  obj.sample(2,3);
    console.log(item1)

    let item2 =  obj.sample(5,3);
    console.log(item2);

    let sample = myfunction(3,4);
console.log(sample)
    function myfunction(a,b) {
      return a*b;
    }


    function first() {
      console.log("first")
    }

    function second() {
      console.log("second")
    }
    second();
    first();
   

  }

  submit1() {
//call
    let obj = {
      name:'hemanth',
      age:28
    }

    //call,apply

    const obj1 ={
      item:function(a,b) {
        return this.name+" "+ this.age + a +b;
      }
    }

    let data = obj1.item.call(obj,'sai','vijay');////second parameter is not array in apply 
    console.log(data)

    let data1 = obj1.item.apply(obj,['sai','vijay']); //second parameter is array in apply 
    console.log(data1)
  }

  submit2() {

    //asynchronous calls
  
    setTimeout(()=>{
      console.log("first item")
    },2000) //2 sec

    setTimeout(()=>{
      console.log("third item")
    },1000)

    console.log("second item")

    //setinterval

   let item = setInterval(() =>{
    for(let i=0;i<5;i++) {
      if(i===4) {
        clearInterval(item)
      }
      console.log(i);
    }
    })

    setInterval(()=>{
      console.log("first item")
    },6000) // for every six seconds it shows output in console
 

    let ietm = myfunction(4);
    console.log(ietm);
    let ietm1 = myfunction(5);
    console.log(ietm1)

    function myfunction(a) {
      let sum =0;
      for(let i=0;i<a;i++) {
         sum = sum +i;
      }
      return sum;
    }
  }

}
