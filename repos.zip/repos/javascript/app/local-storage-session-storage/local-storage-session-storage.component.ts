import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-local-storage-session-storage',
  templateUrl: './local-storage-session-storage.component.html',
  styleUrls: ['./local-storage-session-storage.component.css']
})
export class LocalStorageSessionStorageComponent implements OnInit {

  constructor() { }

  public obj ={
    name:'hemanth',
    age:'40'
  }
  public age = 20;
public simpledata;
public simpledata1;
public item;
  ngOnInit() {
  }
submit() {
  let year = this.age.toString();
  //key is first parameter // value is second parameter (value showld be string)
localStorage.setItem('data',year);

sessionStorage.setItem('data',year);

localStorage.setItem('data1',JSON.stringify(this.obj))
sessionStorage.setItem('data1',JSON.stringify(this.obj))

this.item = {
  "mainItem": {
      "school": [
          {
              "school1": "govt school1"
          },
          {
              "school2": "govt school2"
          },
          {
              "school3": "govt school3"
          }
      ],
      "college": [
          {
              "school1": "govt college1"
          },
          {
              "school2": "govt college2"
          },
          {
              "school3": "govt college3"
          }
      ]
  }
}
localStorage.setItem('data2',JSON.stringify(this.item))

}

submit1() {
  // key
 this.simpledata =  localStorage.getItem('data');
 console.log(this.simpledata);
 this.simpledata1 = localStorage.getItem('data1');
 console.log(this.simpledata1);
 console.log(JSON.parse(this.simpledata1));
 console.log(localStorage.getItem('data2'));
 console.log(JSON.parse(localStorage.getItem('data2')))

}
submit2() {
  localStorage.removeItem('data');
  sessionStorage.removeItem('data')
}

submit3() {
  localStorage.clear();
  sessionStorage.clear();


  let obj3={data:"sai1", data2:"siri",data3:43};
  // Object.keys(obj3).forEach((element,index)=>{
  //   if(obj[element]==="siri"){
  //     obj[element]="laxmi"
  //   }
  // })

  // Object.keys(obj3).forEach((element,index)=>{
  //   if(obj3[element] === 'siri') {
  //     obj3[element] = 'lakshmi'
  //   }
  // })

  // console.log(obj3);

  for(let i=0;i<  Object.keys(obj3).length;i++) {
    if(Object.values(obj3)[i] === 'siri') {
      obj3[(Object.keys(obj3))[i]] = 'lakshmi' //obj3['data2]
    }
  }
  console.log(obj3);
}

}
