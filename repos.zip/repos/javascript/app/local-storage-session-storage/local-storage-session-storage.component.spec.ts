import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocalStorageSessionStorageComponent } from './local-storage-session-storage.component';

describe('LocalStorageSessionStorageComponent', () => {
  let component: LocalStorageSessionStorageComponent;
  let fixture: ComponentFixture<LocalStorageSessionStorageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocalStorageSessionStorageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocalStorageSessionStorageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
