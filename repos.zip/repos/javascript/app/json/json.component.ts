import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-json',
  templateUrl: './json.component.html',
  styleUrls: ['./json.component.css']
})
export class JsonComponent implements OnInit {
  public jsonData;
  public simpleData;
  public simple = [];
  public simple1 = [];
  public simple2 = [];

  //objects

  public simpleObject;
  public keys = [];
  public values = [];
  public normal = [];

  //json
  public jsondata1;
  public jsondata2;
  public jsondata3;
  constructor() { }

  ngOnInit() {
  }

  clickme() {
    //Json javascript object notation
    // 1. JSON.parse(data) converts string to object or normal text
    // 2. JSON.stringify(data) converts object or normal text to string

    let jsonItem = {
      mainItem: {
      school: [
        {
          school1: 'govt school1'
        },
        {
          school2: 'govt school2'
        },
        {
          school3: 'govt school3'
        }
      ],
      college: [
        {
          school1: 'govt college1'
        },
        {
          school2: 'govt college2'
        },
        {
          school3: 'govt college3'
        }
      ]
    }

    }

    this.jsonData = jsonItem;
    this.simpleData =  Object.values(jsonItem.mainItem)[0].concat(Object.values(jsonItem.mainItem)[1]);
 let array =[]
    this.simpleData.forEach((element,index) => {
      array.push(Object.values(element)[0])
      
    });
    console.log(array)
    this.simpleData = array;

    let data = ['bmw','volta','nexa','maruti']
    let data1 = {data:'hemu'}

  let item =  JSON.stringify(data);
   let item1 =  JSON.stringify(data1);


    let data2 = '["bmw","volta","nexa","maruti"]'
    let data3 = '{"data":"hemu"}'
    let item3 = JSON.parse(data2);
    let item4 = JSON.parse(data3);

  }



//   tasks1

//   let data = ['bmw','volta','nexa','maruti',54,45,67,-24,-43,0.45,0.23]

//   1. show in screen    sample1
//   2. show only strings and numbers in screen sample2
//   3. show numbers which are decimals
//   4. show numbers which are negative
//   5. convert  [54,45,67,-24,-43,0.45,0.23,'bmw','volta','nexa','maruti']
//   6. show numbers which are greater than 50


// tasks 2

// let person = {
//   firstName: "John",
//   lastName: "Doe",
//   age: 50,
//   eyeColor: "blue"
// };

// 1. show this object in screen
// 2. show keys and values in screen

// 3. show only numbers and strings in screen
// 4. show only 50 



// tasks 3

// let jsonItem = {
//   mainItem: {
//   school: [
//     {
//       school1: 'govt school1'
//     },
//     {
//       school2: 'govt school2'
//     },
//     {
//       school3: 'govt school3'
//     },
//     {
//       school4: 66
//     },
//     {
//       school4: 96
//     }
//   ],
//   ],
//   college: [
//     {
//       school1: 'govt college1'
//     },
//     {
//       school2: 'govt college2'
//     },
//     {
//       school3: 'govt college3'
//     },
//     {
//       school4: 56
//     },
//     {
//       school5: 76
//     }
//   ]
// }

// }


// 1. show  strings and numbers
// 2. show numbers greater than 56

// 3.  {
//   school2: 'govt college2'
// },     length of string


// 4.  {
//   school1: 'govt college1'
// },  count the number of 'e' in the string


// 5.{
//   school2: 'govt school2'
// },   convert to 'school2 govt'


click() {
let data = ['bmw','volta','nexa','maruti',54,45,67,-24,-43,0.45,0.23]

this.simple= data;
// this.simple1 = data;
data.forEach((element) =>{
  if(typeof element === 'number' && element.toString().split('.').length > 1) {
      this.simple1.push(element)
    }


})


data.forEach((element) =>{
  if(typeof element === 'number' && element<0) {
      this.simple2.push(element)
    }


})

let simpl = data.filter(x => x < 0);
console.log(simpl);

// let sample = data.lastIndexOf(x => x <0);
// console.log(sample)
let arr = []
for(let i=0;i<data.length;i++){
  if(typeof data[i] === 'number' && data[i]<0) {
  arr.push(data[i])
  }
}
console.log(arr)
}


clickmes() {
  let person = {
  firstName: "John",
  lastName: "Doe",
  age: 50,
  eyeColor: "blue"
};
this.simpleObject = Object.assign({},person);

 this.keys = Object.keys(person);
 this.values = Object.values(person);
// this.normal = Object.values(person);
this.values.forEach((element) => {
if(typeof element === 'string') {
  this.normal.push(element)
}
})


this.values.forEach((element) => {
  if(typeof element === 'number' && element === 50) {
    this.normal.push(element)
  }
  })


 


}

clickIems() {
  let jsonItem = {
    mainItem: {
    school: [
      {
        school1: 'govt school1'
      },
      {
        school2: 'govt school2'
      },
      {
        school3: 'govt school3'
      }
    ],
    college: [
      {
        school1: 'govt college1'
      },
      {
        school2: 'govt college2'
      },
      {
        school3: 'govt college3'
      }
    ]
  }

  }
  this.jsondata1 =  Object.values(jsonItem.mainItem.school[1])[0].length;
 let data2 = Object.values(jsonItem.mainItem.college[1])[0];
let count =0;
 for(let i=0;i<data2.length;i++) {
if(data2[i] === 'e') {
  count++;
}
 }
 console.log(count);
 this.jsondata2 = count;
 this.jsondata3 = Object.values(jsonItem.mainItem.school[1])[0];
 this.jsondata3 = this.jsondata3.split(' ')[1] + " " +this.jsondata3.split(' ')[0];
 console.log(this.jsondata3)

}


}
