import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import { ArrayObjectComponent } from './array-object/array-object.component';
import { DocumentComponent } from './document/document.component';
import { StringComponent } from './string/string.component';
import { JsonComponent } from './json/json.component';
import { ExternalJsonComponent } from './external-json/external-json.component';
import { LocalStorageSessionStorageComponent } from './local-storage-session-storage/local-storage-session-storage.component';
import { FunctionsComponent } from './functions/functions.component';
import { OtherThingsComponent } from './other-things/other-things.component';
import { DynamicDataComponent } from './dynamic-data/dynamic-data.component';
import { TableComponent } from './table/table.component';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    ArrayObjectComponent,
    DocumentComponent,
    StringComponent,
    JsonComponent,
    ExternalJsonComponent,
    LocalStorageSessionStorageComponent,
    FunctionsComponent,
    OtherThingsComponent,
    DynamicDataComponent,
    TableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
