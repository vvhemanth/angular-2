import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-string',
  templateUrl: './string.component.html',
  styleUrls: ['./string.component.css']
})
export class StringComponent implements OnInit {

  public simpleArray = [];
  simpleArray1 = [];
  simpleArray2 = [];
  simpleArray3 = [];
  public simpleObject = {};
  public data ='item';
  public jsonData;
  constructor() { }

  ngOnInit() {
  }

  ischanged() {

    let data ="hemu,raja,sai,rush,raja";
    console.log(data.length)
    console.log(data.split(','))
    console.log(data.substring(5,9))
    console.log(data.slice(5,9))
    console.log(data.indexOf('r'))
    console.log(data.lastIndexOf('r'))
   // data.replaceAll('raja','rajesh')
    console.log(data)

    let data1="hemanth"
    let data2 ="sai"
    let data3 = data1.concat(",",data2)
    console.log(data3)

    let simple ="   hello world!    "
    console.log(simple)
    console.log(simple.trim())
    console.log(data1.charAt(2))

    let data12 ="hellow hemanth";

      console.log(data12[4]) // same as charAt
      console.log(data12.search("hema"))

      let data123 = "hemanth is coding data"
      console.log(data123.includes('coding123'))
      console.log(data123.startsWith('hemanth'))
      console.log(data123.startsWith('is',9))
      console.log(data123.toLowerCase())
      console.log(data123.endsWith('data'))
      console.log(data123.endsWith('is',10))
      console.log(data123.repeat(2))
      // let item='23';
      // console.log(typeof item.toString())



  }

  isclicked() {
    // {data1:'hemu'} data1 : key ,hemu is value
    let array = [{data1:'hemu'},{data2:'raja'},{data3:'sai'},{data4:56},{data5:76},45,67]
   // this.simpleArray = array;
    array.forEach((element,index) =>{
      this.simpleArray.push(Object.values(element)[0])
    })
    console.log(this.simpleArray)
    array.forEach((element,index) =>{
      if(typeof Object.values(element)[0] === 'string') {
        this.simpleArray1.push(Object.values(element)[0])
      }

      if(typeof Object.values(element)[0] === 'number') {
        this.simpleArray2.push(Object.values(element)[0])
      } else if(typeof element === 'number' ) {
        this.simpleArray2.push(element);
      }
      
    })

    let obj = {
      data1: 'hemu',
      data2:'raja',
      data3:'rajesh'
    }

    let obj1 = {
      "data1": 'hemu',
      "data2":'raja',
      "data3":'rajesh'
    }
    this.simpleObject = Object.assign({},obj1)
    this.simpleArray3.push(Object.values(obj1))


  }


  JSON

  clickme() {
    let jsonItem = {
      mainItem: {
      school: [
        {
          school1: 'govt school1'
        },
        {
          school2: 'govt school2'
        },
        {
          school2: 'govt school2'
        }
      ],
      college: [
        {
          school1: 'govt school1'
        },
        {
          school2: 'govt school2'
        },
        {
          school2: 'govt school2'
        }
      ]
    }

    }

    this.jsonData = JSON.parse(JSON.stringify(jsonItem)).mainItem
  }


}
