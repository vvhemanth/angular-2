import { Component, OnInit } from '@angular/core';
import{HttpClient} from '@angular/common/http'
@Component({
  selector: 'app-external-json',
  templateUrl: './external-json.component.html',
  styleUrls: ['./external-json.component.css']
})
export class ExternalJsonComponent implements OnInit {

  constructor(private http:HttpClient) { //on load 1
    // this.submit(); // no data
    }
 public simpledata;
 public simpledata1;
   ngOnInit() { //on load 2 // data comes
   //  this.submit();
   }
 
   submit(name) {
 
     this.http.get('assets/'+name+'.json').subscribe(data => {
       console.log(data);
        let count =0; let count1 =0;
       // data.main
       Object.keys(data['mainItem']).forEach((element)=>{
       //  console.log(element)
         data['mainItem'].element.forEach(element => {
         if(typeof Object.values(element)[0] === 'string' ) {
           count++;
         }
       });
       })
       // let count =0; let count1 =0;
       // let simplearra= [];
       // data['mainItem']["school"].forEach(element => {
       //   if(typeof Object.values(element)[0] === 'string' ) {
       //     count++;
       //   }
       // });
       
       
       // data['mainItem']["college"].forEach(element => {
       //   if(typeof Object.values(element)[0] === 'string' ) {
       //     count++;
       //   }
       // });
       // console.log(count);
 
       // simplearra = data['mainItem']["school"].concat(data['mainItem']["college"]);
 
       // simplearra.forEach(element => {
       //   if(typeof Object.values(element)[0] === 'string' ) {
       //     count1++;
       //   }
       // });
 
       // console.log(count1)
 
     })
    
 
     this.http.get('https://api.npms.io/v2/search?q=scope:angular').subscribe((data) => {
       console.log(data)
 this.simpledata = data;
 this.simpledata1 = data;
 let arr = [];
 this.simpledata.results.forEach(element => {
   if(element.package.name === '@angular/material') {
     arr.push(element.package.scope);
     arr.push(element.package.version)
   }
 });
 console.log(arr)
 this.simpledata = arr;
 
 
 
 //  // frontend ,backend
   
 //  Rest api services
 // // backend                   
 //  let  obj ={
 //   name:'hemanth',
 //   age:'40'
 // }
 
 // //frontend to get data
 
 // this.http.get('url')
 // let  obj ={
 //   name:'hemanth',
 //   age:'40'
 // }
 
 // // frontend (id)
 // let  obj ={
 //   name:'hemanth1212',
 //   age:'40121'
 // }
 
 // // backend (sql db,mongodb)
 // this.http.post('')
 
 
 // //backend 
 // this.http.delete(id)
 
 // //update
 
 // this.http.post(id,obj)
 
 // let  obj ={
 //   name:'hemanth12',
 //   age:'40'
 // }
 
 
 
     })
 
   
   }
  }
