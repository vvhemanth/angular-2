import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalJsonComponent } from './external-json.component';

describe('ExternalJsonComponent', () => {
  let component: ExternalJsonComponent;
  let fixture: ComponentFixture<ExternalJsonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExternalJsonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExternalJsonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
