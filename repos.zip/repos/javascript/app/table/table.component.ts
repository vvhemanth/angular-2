import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  constructor() { }


  public json = [
    {
      'college':"1",
      "collge_name":'Aditya',
      'branch':'cse',
      'fees':30000
    },
    {
      'college':"2",
      "collge_name":'gitam',
      'branch':'cse',
      'fees':40000
    },
    {
      'college':"3",
      "collge_name":'andhra university',
      'branch':'cse',
      'fees':50000
    }, {
      'college':"4",
      "collge_name":'jntuk',
      'branch':'cse',
      'fees':60000
    },
    {
      'college':"5",
      "collge_name":'vits',
      'branch':'cse',
      'fees':70000
    }
  ]
  ngOnInit() {

  }


  submit() {
    document.getElementById('tabledata').innerHTML = ''
     
    //  for(let i =0; i<this.json.length;i++) {
    //    for(var key  in this.json[i]){
    //      if(col.indexOf(key) === -1) {
    //        col.push(key);
    //      }
    //    }
    //  }

   
  // item.appendChild(table)
  this.createTable(this.json)


  }


  createTable(tableData) {
    var col = [];
    tableData.forEach((element,index) => {
      if(index === 0) {
      col.push(Object.keys(element))
      col = col[0];
      }

    })
    console.log(col)

    var table = document.createElement('table') //<table></table>
    table.setAttribute('class','sample')

    var tr = table.insertRow(-1); //it creates a row


    for(let i=0; i<tableData.length-1;i++){
      var th = document.createElement('th');
      th.innerHTML = col[i];
      tr.appendChild(th);
    }

    



    //create td

    for(let i=0; i< tableData.length;i++) {
      tr = table.insertRow(-1);
 // 5 trs

      for(let j=0;j < col.length ;j++) {
        var td = tr.insertCell(-1);
       // td.innerHTML = this.json[i][col[j]]
       td.textContent = tableData[i][col[j]]
      }
    }

   
   var item = document.getElementById('tabledata').appendChild(table);
 
  }


  selectitem() {

    let arr = [];
    this.json.forEach(element => {
      arr.push(element.college)
    });
    console.log(arr)
    document.getElementById('tabledata').innerHTML = ''
    var item = (document.getElementById('select') as HTMLInputElement).value;
    let index = this.json.findIndex( x => x.college === item) ; 
    let sample = this.json[index];

    let sampleArray =  [];
    sampleArray.push(sample);
    this.createTable(sampleArray)
    console.log(sampleArray)
  
  }
}
