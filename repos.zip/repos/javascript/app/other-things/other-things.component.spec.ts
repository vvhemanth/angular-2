import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherThingsComponent } from './other-things.component';

describe('OtherThingsComponent', () => {
  let component: OtherThingsComponent;
  let fixture: ComponentFixture<OtherThingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherThingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherThingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
