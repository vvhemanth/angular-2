import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-things',
  templateUrl: './other-things.component.html',
  styleUrls: ['./other-things.component.css']
})
export class OtherThingsComponent implements OnInit {

  
  public item: string; //type
  public item1: string = ''; //type
  public item2 = ''; //type

  public sim:boolean; //true or false
  public sim1 = false;
  public sim2:boolean = false;

  public arr1 = [];
  public obj = {};

  public sampleDate :Date; // date
  public sampleDate1  = '2022-01-01';// date in the form of string
  

  public buttonDisabled = false;
  public samplevalue;

  constructor() {
    
   }
// date //closures // input //class
  ngOnInit() {
    
  }

  sample() {
 this.sampleDate = new Date();
 console.log(this.sampleDate);

 let date = this.sampleDate.getDate();
 let year = this.sampleDate.getFullYear();
 let month = this.sampleDate.getMonth()+'1';


 this.sampleDate1 = year+'-'+month+'-'+date;
  }

  Onblur(event) {
    console.log(event)
    let data = parseInt(event.target.getAttribute('value'))
   // let data = parseInt((document.getElementById('demo') as HTMLInputElement).value);
    function myfunction() {
      
      if(data % 5 === 0) {
        document.getElementById('clear').setAttribute('class','sample')
        return data.toString() + '.5';
      } else {
        return null;
      }
    
    }

    this.samplevalue = myfunction();

  }


  Onfocus (event) {
    console.log(event)
    let data = parseInt(event.target.getAttribute('value'))
   // let data = parseInt((document.getElementById('demo') as HTMLInputElement).value);
    function myfunction() {
      
      if(data % 5 === 0) {
        document.getElementById('clear').removeAttribute('class')
        return data.toString() + '.50'
      } else {
        return null;
      }
    
    }

    this.samplevalue = myfunction();

  }

  clickme() {
    let a =10; // global variable
    function sample() {
      let a = 5; //local variable 
      return a*a;
    }

    let item = sample();
    console.log(item)
  }

  clickItem() {
    let obj ={
      name:'hemu',
      age:'20'
    }

    class Item {
      name1: any;
      age1: any;
      constructor(name1,age1) {
        this.name1 = name1;
        this.age1 =  age1;
      }
    }


    let user1 = new Item('hemu',34);
    let user2 = new Item('sai',23);

    console.log(user1);
    console.log(user2)


    
  }

}
