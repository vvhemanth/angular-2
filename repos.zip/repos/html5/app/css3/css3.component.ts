import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-css3',
  templateUrl: './css3.component.html',
  styleUrls: ['./css3.component.css']
})
export class Css3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
