import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ResponsiveComponent } from './responsive/responsive.component';
import { WebsiteComponent } from './website/website.component';
import { Html5ConceptsComponent } from './html5-concepts/html5-concepts.component';
import { AppRoutingModule } from './app.routing.module';
import { Css3Component } from './css3/css3.component';

@NgModule({
  declarations: [
    AppComponent,
    ResponsiveComponent,
    WebsiteComponent,
    Html5ConceptsComponent,
    Css3Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
