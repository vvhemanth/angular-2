import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-html5-concepts',
  templateUrl: './html5-concepts.component.html',
  styleUrls: ['./html5-concepts.component.css']
})
export class Html5ConceptsComponent implements OnInit {

  constructor() { }
  title = 'html5';
  ngOnInit() {
  }

}
