import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Html5ConceptsComponent } from './html5-concepts.component';

describe('Html5ConceptsComponent', () => {
  let component: Html5ConceptsComponent;
  let fixture: ComponentFixture<Html5ConceptsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Html5ConceptsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Html5ConceptsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
