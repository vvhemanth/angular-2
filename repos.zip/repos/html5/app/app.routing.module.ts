import { NgModule } from "@angular/core";
import {Routes,RouterModule} from '@angular/router';
import { Css3Component } from "./css3/css3.component";
import { Html5ConceptsComponent } from "./html5-concepts/html5-concepts.component";
import { ResponsiveComponent } from "./responsive/responsive.component";
import { WebsiteComponent } from "./website/website.component";

const routes: Routes = [
    {
        path:'website',
        component:WebsiteComponent
    },{
        path:'responsive',
        component:ResponsiveComponent
    },
    {
        path:'html5-conepts',
        component:Html5ConceptsComponent
    },
    {
        path:'css3',
        component:Css3Component
    }
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule],
})
export class AppRoutingModule{}