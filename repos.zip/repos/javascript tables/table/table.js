
var json = [
    {
    "book":"1",
    "bookname":"science",
    "price":"20"
},
{
    "book":"2",
    "bookname":"social",
    "price":"30"
},
{
    "book":"3",
    "bookname":"maths",
    "price":"50"
},
{
    "book":"4",
    "bookname":"physics",
    "price":"70"
},

]

var dropdownitem;var dropdownitem1;

function createTable(json) {
    document.getElementById('main').innerHTML ='sample website';

    

let tableHtml ="<table> gneral table";  
 tableHtml += "<tr>"; //<table> gneral table <tr>

 json.forEach(function(element) {
     if(json.length ===1) {
                   for(let i = 0;i<=json.length+1;i++) {  //<tr> <td>sd</td><td>sdsd</td>dfdffd
                      // tableHtml += `<td>${Object.values(element)[i]}</td>`
                      tableHtml += '<td>'+Object.values(element)[i]+'</td>'
                   }
                   tableHtml += "</tr>"  //<tr> <td>sd</td><td>sdsd</td>dfdffd</tr>
                } else {
                    for(let i = 0;i<json.length-1;i++) {  //<tr> <td>sd</td><td>sdsd</td>dfdffd
                        // tableHtml += `<td>${Object.values(element)[i]}</td>`
                        tableHtml += '<td>'+Object.values(element)[i]+'</td>'
                     }
                     tableHtml += "</tr>" 
                }
 })
 tableHtml +='</table>' //

 let table = document.getElementById('table');
 table.innerHTML = tableHtml;







}


function dropdownChange() {
    dropdownitem = document.getElementById('select').value;
 // console.log(item)

}

function dropdownChange1() {
    dropdownitem1 = document.getElementById('select1').value;
  //   console.log(item)
   
   }

function Load(json) {
    this.createTable(json);
  //  let array = [];
    let select = document.getElementById('select');
   
    json.forEach((element) =>{
        let option = document.createElement('option');//option
      //  let text = document.createTextNode(element.book);//1
      option.textContent =  element.book;
         // option.innerHTML = text; //<option> 1</option>
          select.appendChild(option)
      //  array.push(book);

    })
  


    let select1 = document.getElementById('select1');

    json.forEach((element) =>{
        let option = document.createElement('option');//option
      //  let text = document.createTextNode(element.book);//1
      option.textContent =  element.bookname;
         // option.innerHTML = text; //<option> 1</option>
          select1.appendChild(option)
      //  array.push(book);

    })



}



function sampleTable() {
  let array = [];
    json.forEach((element,index) =>{
        if(element.book === dropdownitem && element.bookname === dropdownitem1) {
            array.push(json[index])
        }
    })

  //  document.getElementById('table').innerHTML = ''
     this.createTable(array);
    console.log(array)
  
}



