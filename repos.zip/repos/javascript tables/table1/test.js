let url =  'https://jsonplaceholder.typicode.com/todos';
let dropdowndata1;
let dropdowndata2;
let storeJson;
 fetch(url).then(function(response) {
    return response.json()
 }).then(function(json) {
   createTable(json)
   dropdown(json)
 })

 function createTable(json) {
console.log(json)
 const mytable = document.getElementById('html-data-table');
 let tr = document.createElement('tr');
   Object.keys(json[0]).forEach(Element =>{
       let th = document.createElement('th');
       th.innerText = Element;
       tr.appendChild(th);
   })
   mytable.appendChild(tr)

   json.forEach(element =>{
       let tr = document.createElement('tr');
       Object.values(element).forEach(item => {
           let td = document.createElement('td');
           td.innerText = item;
           tr.appendChild(td);

       })
       mytable.appendChild(tr);
   })
 }


 function dropdown(json) {
     let select = document.getElementById('select');
     let select1 = document.getElementById('select1');
     this.storeJson = json;
     json.forEach(element =>{
         let option = document.createElement('option');
         let option1 = document.createElement('option');

         for(let i=0;i<Object.keys(element).length;i++) {
             if(Object.keys(element)[i] === 'id') {
                 option.innerText = Object.values(element)[i]
                 select.appendChild(option)
             }

             if(Object.keys(element)[i] === 'title') {
                option1.innerText = Object.values(element)[i]
                select1.appendChild(option1)
            }

         }

     })

 }

 function change() {
     document.getElementById('select1').value='sample';
    dropdowndata1 = document.getElementById('select').value;
    console.log(dropdowndata1)
 }
 function change1() {
    dropdowndata2 = document.getElementById('select1').value;
    console.log(dropdowndata2)
}
 
 function submit() {
     document.getElementById('html-data-table').innerHTML = '';
     let array = [];
    this.storeJson.forEach(element =>{
        for(let i=0;i<Object.keys(element).length;i++) {
            if((Object.keys(element)[i] === 'id' && Object.values(element)[i] === parseInt(dropdowndata1)) || 
            (Object.values(element)[i] === dropdowndata2)) {
               array.push(element);
            }
        }
    })
    if(array.length) {
        this.createTable(array);
    }
 }