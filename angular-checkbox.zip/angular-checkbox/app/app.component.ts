import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-checkbox';
  cbList = [
    {'name':'gender','value':'male','heading':'male','checked':true},
    {'name':'gender','value':'female','heading':'female','checked':false},
    {'name':'gender','value':'other','heading':'other','checked':false}
  ]
  onChange(event) {
    console.log(event)
  }
}
