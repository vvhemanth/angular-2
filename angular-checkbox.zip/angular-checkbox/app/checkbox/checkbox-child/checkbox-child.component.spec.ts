import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxChildComponent } from './checkbox-child.component';

describe('CheckboxChildComponent', () => {
  let component: CheckboxChildComponent;
  let fixture: ComponentFixture<CheckboxChildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckboxChildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckboxChildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
