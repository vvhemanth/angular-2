import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxParentComponent } from './checkbox-parent.component';

describe('CheckboxParentComponent', () => {
  let component: CheckboxParentComponent;
  let fixture: ComponentFixture<CheckboxParentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckboxParentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckboxParentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
